import { defineConfig, devices } from '@playwright/test';



/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// import dotenv from 'dotenv';
//import path from 'path';
//dotenv.config({ path: path.resolve(__dirname, '.env') });
require('dotenv').config();
/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
  testDir: './tests',
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 5 : 5,
     
  reporter: [
    ['html'],
    ['allure-playwright']

  ],
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
   
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
    /* Base URL to use in actions like `await page.goto('/')`. */
    // baseURL: 'http://127.0.0.1:3000',

    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    video: 'on',
    screenshot:'only-on-failure',
    headless: true,
    trace: 'on',
  },

  /* Configure projects for major browsers */
  projects: [
    
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'], 
              headless: true
      },
    }, 


    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },

    {
       name: 'Microsoft Edge',
       use: { ...devices['Desktop Edge'], headless: true, channel: 'msedge' },
    },
    {
       name: 'Google Chrome',
       use: { ...devices['Desktop Chrome'], headless: true, channel: 'chrome' },
     },
     {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'],headless: true },
    },
    
     
  ],

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://127.0.0.1:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});
