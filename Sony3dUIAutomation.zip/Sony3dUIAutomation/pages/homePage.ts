import { Locator, Page, expect } from '@playwright/test';
class HomePage {
    page: Page;
    homePageTitle: Locator;
    sonyImage: Locator;

    constructor(page:Page) {
        this.page = page;
        this.homePageTitle = page.locator('text=XYZ Capture');
        this.sonyImage = page.locator('#root > div > header > img');
        
    }
    
    async navigate() {
        await this.page.setViewportSize({width:1366,height:728})
        await this.page.goto('https://sonyxyzfrontend-test.azurewebsites.net/');
    }

}
export default HomePage;