import { test, expect, chromium, BrowserContext } from '@playwright/test';
let sony3DHomePageURL = 'https://sonyxyzfrontend-test.azurewebsites.net/';
let sonyLoginPageURL = 'https://sonyxyzfrontend-test.azurewebsites.net/#/login';


test('Verify Generation of 3D Model Using First Sony Algorithm Sony NERF Include Sparse', async ({ page }) => {
    await page.goto(sony3DHomePageURL);
    await page.waitForURL(sony3DHomePageURL);
    const homePageURL = page.url();
    console.log("Sony 3D Creation Home Page URL::= " + homePageURL);
    expect(homePageURL).toBe(sony3DHomePageURL);
    await expect(page).toHaveTitle('XYZ Capture');

    // Click on Login Button to Navigate to Login page
    const loginButton = page.getByRole('button', { name: 'Login' });
    await expect(loginButton).toBeVisible();

    //Click on Login Button
    await loginButton.click();
    const expectedLoginURL = sonyLoginPageURL;
    const currentLoginURL = page.url();
    console.log("Sony 3D Login URL::= ", currentLoginURL);
    expect(currentLoginURL).toBe(expectedLoginURL);

    const welcomeMessage = await (page.getByText('Welcome'));
    expect(welcomeMessage).toBeVisible();

    // verify sign in with Google Button.
    const googleSignInButton = page.getByRole('button', { name: 'Sign in with Google' });
    await googleSignInButton.waitFor({ state: 'visible' });
    expect(googleSignInButton).toBeVisible();
    await googleSignInButton.click();
    if (googleSignInButton) {
        console.log("Login Button is clicked successfully.")
    } else {
        console.error("Login Button is not clicked successfully.")
    }

    const scrollY = await page.evaluate(() => document.body.scrollHeight); // get the page height
    await page.mouse.wheel(0, scrollY); // scroll to the bottom


    await page.setExtraHTTPHeaders({
        'accept-language': 'en-US,en;q=0.9,hy=0.8'

    });

    await page.evaluate(() => {
        localStorage.setItem('authToken', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ')
        localStorage.setItem("loggedIn", true);
        localStorage.setItem('tokenExpiration', '1733415502652');
        localStorage.setItem('refreshToken', '1//0eJH0C9YQixpICgYIARAAGA4SNwF-L9IrNgiFdIjTkUvi_c0d2bM7SLhir1kkt7gbKLsL5G8sjVGW1kgNPopagegqmB99tjKoyeU');
    });


    let bearerToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ'

    page.on('route', (route, request) => {
        const modifieldHeaders = {
            ...request.headers(),
            'Authorization': `Bearer ${bearerToken}`
        }
        route.continue({ headers: modifieldHeaders })
    });

    await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/3d-creation");
    const creation3DPageURL = page.url();
    console.log("Sony 3D Creation Web Page URL::= " + creation3DPageURL);
    //expect(creation3DPageURL).toBe(expectedCreation3DPage);
    await expect(page).toHaveTitle('XYZ Capture');

    //Verify Sony Logo
    const imageSelector = '#root > div > header > img';
    await page.waitForSelector(imageSelector, { state: 'visible' });
    console.log("Sony Image LOGO Present in the page");
    const imgSrc = await page.getAttribute(imageSelector, 'src');
    console.log(imgSrc);
    if (imgSrc == '/static/media/sony-logo.793747a6e91237b8077ec0576d61e364.svg') {
        console.log("Sony Logo is Showing");
    } else {
        console.log("Sony Logo is Not Showing");
    }

    const creationTextExists = page.locator('//div[@class="appStorePortalHeader" and text()= "3D Capture Creation"]');
    const creationSuiteTextBoundingBox = await creationTextExists.boundingBox();
    console.log("Sony XYZ Creation Suite Bounding Box Dimentions::=", creationSuiteTextBoundingBox);

    await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/main/cdd935fc-20f4-42f8-8f4e-d550a4519413/2d");
    const creation3DMainPageURL = page.url();
    console.log("Sony 3D Main Web Page URL::= " + creation3DMainPageURL);


    await page.reload();

    // Create A New Project

    const createNewProject = page.getByRole('button', { name: 'Create New' });
    await createNewProject.waitFor({ state: 'visible' });
    expect(createNewProject).toBeVisible();
    createNewProject.click();


    const uploadSelectImages = page.locator('//input[@id="fileElem"]');
    //uploadSelectImages.click();

    // upload multiple Images
    const multipleImagesPaths = [
        './tests/ImagesToUpload/000001.png',
        './tests/ImagesToUpload/000002.png',
        './tests/ImagesToUpload/000003.png',
        './tests/ImagesToUpload/000004.png',
        './tests/ImagesToUpload/000005.png',
        './tests/ImagesToUpload/000006.png',
        './tests/ImagesToUpload/000007.png',
        './tests/ImagesToUpload/000008.png',
        './tests/ImagesToUpload/000009.png',
        './tests/ImagesToUpload/000010.png',
    ]
    await uploadSelectImages.setInputFiles(multipleImagesPaths);

    const uploadButton = page.locator('//button[@class="primary"]');
    await uploadButton.waitFor({ state: 'visible' });
    expect(uploadButton).toBeVisible();
    await uploadButton.click();
    if (uploadButton) {
        console.log("upload Button is clicked successfully.")
    } else {
        console.error("upload Button is not clicked successfully.")
    }

    // Click 3D Model Button
    const button3dModelGeneration = page.locator('//button[@class="outline" and text()="3D Model Generation"]');
    await button3dModelGeneration.waitFor({ state: 'visible' });
    expect(button3dModelGeneration).toBeVisible();
    await button3dModelGeneration.click();
    if (button3dModelGeneration) {
        console.log("3dModel Generation Button is clicked successfully.")
    } else {
        console.error("3dModel Generation Button is not clicked successfully.")
    }

    // Select Sony NERF Algorithm
    const selectNERFAlgo = page.locator('//div[@class="profile-selection-footer" and text()="Sony NeRF"]');
    await selectNERFAlgo.waitFor({ state: 'visible' });
    expect(selectNERFAlgo).toBeVisible();
    await selectNERFAlgo.click();
    if (selectNERFAlgo) {
        console.log("Sony NeRF Algorithm Image is clicked successfully.")
    } else {
        console.error("Sony NeRF Algorithm Image is not clicked successfully.")
    }

    // Click on Next Button
    const nextButtonClick = page.locator('//button[@class="primary" and text()="Next"]');
    await nextButtonClick.waitFor({ state: 'visible' });
    expect(nextButtonClick).toBeVisible();
    await nextButtonClick.click();
    if (nextButtonClick) {
        console.log("Next Button is clicked successfully.")
    } else {
        console.error("Next Button is not clicked successfully.")
    }

    // Select All Check Boxes

   // Select All Check Boxes
   const spareCheckBox = await page.locator('//label[@class="global-checkbox-label" and @for="1"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="1"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="2"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="3"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="4"]');
   await spareCheckBox.click();
   if(spareCheckBox) {
       console.log("Sparse Check Box is clicked successfully.")
   }
   else {
       console.error("Sparse Check Box is not clicked successfully.")
   }

    // Click on Ok Button
    const okButton = page.locator('//button[@class="primary" and text()="Ok"]');
    await okButton.waitFor({ state: 'visible' });
    expect(okButton).toBeVisible();
    await okButton.click();
    if (okButton) {
        console.log("Ok Button is clicked successfully.")
    } else {
        console.error("OK Button is not clicked successfully.")
    }

    // Dismiss Pop up Message
    const dismisspopup = page.locator('//div[@class="text-wrapper" and text()="DISMISS"]');
    await dismisspopup.waitFor({ state: 'visible' });
    expect(dismisspopup).toBeVisible();
    await dismisspopup.click();
    if (dismisspopup) {
        console.log("Dismiss popup is clicked successfully.")
    } else {
        console.error("Dismiss popup is not clicked successfully.")
    }



});


test('Verify Generation of 3D Model Using First Sony Algorithm Sony NERF Include Dense', async ({ page }) => {
    await page.goto(sony3DHomePageURL);
    await page.waitForURL(sony3DHomePageURL);
    const homePageURL = page.url();
    console.log("Sony 3D Creation Home Page URL::= " + homePageURL);
    expect(homePageURL).toBe(sony3DHomePageURL);
    await expect(page).toHaveTitle('XYZ Capture');

    // Click on Login Button to Navigate to Login page
    const loginButton = page.getByRole('button', { name: 'Login' });
    await expect(loginButton).toBeVisible();

    //Click on Login Button
    await loginButton.click();
    const expectedLoginURL = sonyLoginPageURL;
    const currentLoginURL = page.url();
    console.log("Sony 3D Login URL::= ", currentLoginURL);
    expect(currentLoginURL).toBe(expectedLoginURL);

    const welcomeMessage = await (page.getByText('Welcome'));
    expect(welcomeMessage).toBeVisible();

    // verify sign in with Google Button.
    const googleSignInButton = page.getByRole('button', { name: 'Sign in with Google' });
    await googleSignInButton.waitFor({ state: 'visible' });
    expect(googleSignInButton).toBeVisible();
    await googleSignInButton.click();
    if (googleSignInButton) {
        console.log("Login Button is clicked successfully.")
    } else {
        console.error("Login Button is not clicked successfully.")
    }

    const scrollY = await page.evaluate(() => document.body.scrollHeight); // get the page height
    await page.mouse.wheel(0, scrollY); // scroll to the bottom


    await page.setExtraHTTPHeaders({
        'accept-language': 'en-US,en;q=0.9,hy=0.8'

    });

    await page.evaluate(() => {
        localStorage.setItem('authToken', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ')
        localStorage.setItem("loggedIn", true);
        localStorage.setItem('tokenExpiration', '1733415502652');
        localStorage.setItem('refreshToken', '1//0eJH0C9YQixpICgYIARAAGA4SNwF-L9IrNgiFdIjTkUvi_c0d2bM7SLhir1kkt7gbKLsL5G8sjVGW1kgNPopagegqmB99tjKoyeU');
    });


    let bearerToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ'

    page.on('route', (route, request) => {
        const modifieldHeaders = {
            ...request.headers(),
            'Authorization': `Bearer ${bearerToken}`
        }
        route.continue({ headers: modifieldHeaders })
    });

    await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/3d-creation");
    const creation3DPageURL = page.url();
    console.log("Sony 3D Creation Web Page URL::= " + creation3DPageURL);
    //expect(creation3DPageURL).toBe(expectedCreation3DPage);
    await expect(page).toHaveTitle('XYZ Capture');

    //Verify Sony Logo
    const imageSelector = '#root > div > header > img';
    await page.waitForSelector(imageSelector, { state: 'visible' });
    console.log("Sony Image LOGO Present in the page");
    const imgSrc = await page.getAttribute(imageSelector, 'src');
    console.log(imgSrc);
    if (imgSrc == '/static/media/sony-logo.793747a6e91237b8077ec0576d61e364.svg') {
        console.log("Sony Logo is Showing");
    } else {
        console.log("Sony Logo is Not Showing");
    }

    const creationTextExists = page.locator('//div[@class="appStorePortalHeader" and text()= "3D Capture Creation"]');
    const creationSuiteTextBoundingBox = await creationTextExists.boundingBox();
    console.log("Sony XYZ Creation Suite Bounding Box Dimentions::=", creationSuiteTextBoundingBox);

    await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/main/cdd935fc-20f4-42f8-8f4e-d550a4519413/2d");
    const creation3DMainPageURL = page.url();
    console.log("Sony 3D Main Web Page URL::= " + creation3DMainPageURL);


    await page.reload();

    // Create A New Project

    const createNewProject = page.getByRole('button', { name: 'Create New' });
    await createNewProject.waitFor({ state: 'visible' });
    expect(createNewProject).toBeVisible();
    createNewProject.click();


    const uploadSelectImages = page.locator('//input[@id="fileElem"]');
    //uploadSelectImages.click();

    // upload multiple Images
    const multipleImagesPaths = [
        './tests/ImagesToUpload/000001.png',
        './tests/ImagesToUpload/000002.png',
        './tests/ImagesToUpload/000003.png',
        './tests/ImagesToUpload/000004.png',
        './tests/ImagesToUpload/000005.png',
        './tests/ImagesToUpload/000006.png',
        './tests/ImagesToUpload/000007.png',
        './tests/ImagesToUpload/000008.png',
        './tests/ImagesToUpload/000009.png',
        './tests/ImagesToUpload/000010.png',
    ]
    await uploadSelectImages.setInputFiles(multipleImagesPaths);

    const uploadButton = page.locator('//button[@class="primary"]');
    await uploadButton.waitFor({ state: 'visible' });
    expect(uploadButton).toBeVisible();
    await uploadButton.click();
    if (uploadButton) {
        console.log("upload Button is clicked successfully.")
    } else {
        console.error("upload Button is not clicked successfully.")
    }

    // Click 3D Model Button
    const button3dModelGeneration = page.locator('//button[@class="outline" and text()="3D Model Generation"]');
    await button3dModelGeneration.waitFor({ state: 'visible' });
    expect(button3dModelGeneration).toBeVisible();
    await button3dModelGeneration.click();
    if (button3dModelGeneration) {
        console.log("3dModel Generation Button is clicked successfully.")
    } else {
        console.error("3dModel Generation Button is not clicked successfully.")
    }

    // Select Sony NERF Algorithm
    //const selectNERFAlgo = page.locator('//div[@class="profile-selection-footer" and text()="Sony NeRF"]');
    const selectNERFAlgo = page.locator('//div[@class="profile-selection-footer" and text()="Sony NeRF"]');
    await selectNERFAlgo.waitFor({ state: 'visible' });
    expect(selectNERFAlgo).toBeVisible();
    await selectNERFAlgo.click();
    if (selectNERFAlgo) {
        console.log("Sony NeRF Algorithm Image is clicked successfully.")
    } else {
        console.error("Sony NeRF Algorithm Image is not clicked successfully.")
    }

    // Click on Next Button
    const nextButtonClick = page.locator('//button[@class="primary" and text()="Next"]');
    await nextButtonClick.waitFor({ state: 'visible' });
    expect(nextButtonClick).toBeVisible();
    await nextButtonClick.click();
    if (nextButtonClick) {
        console.log("Next Button is clicked successfully.")
    } else {
        console.error("Next Button is not clicked successfully.")
    }

    // Select All Check Boxes

   // Select All Check Boxes
   const denseCheckBox = await page.locator('//label[@class="global-checkbox-label" and @for="2"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="1"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="2"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="3"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="4"]');
   await denseCheckBox.click();
   if(denseCheckBox) {
       console.log("dense Check Box is clicked successfully.")
   }
   else {
       console.error("dense Check Box is not clicked successfully.")
   }

    // Click on Ok Button
    const okButton = page.locator('//button[@class="primary" and text()="Ok"]');
    await okButton.waitFor({ state: 'visible' });
    expect(okButton).toBeVisible();
    await okButton.click();
    if (okButton) {
        console.log("Ok Button is clicked successfully.")
    } else {
        console.error("OK Button is not clicked successfully.")
    }

    // Dismiss Pop up Message
    const dismisspopup = page.locator('//div[@class="text-wrapper" and text()="DISMISS"]');
    await dismisspopup.waitFor({ state: 'visible' });
    expect(dismisspopup).toBeVisible();
    await dismisspopup.click();
    if (dismisspopup) {
        console.log("Dismiss popup is clicked successfully.")
    } else {
        console.error("Dismiss popup is not clicked successfully.")
    }



});


test('Verify Generation of 3D Model Using First Sony Algorithm Sony NERF Include Mesh', async ({ page }) => {
    await page.goto(sony3DHomePageURL);
    await page.waitForURL(sony3DHomePageURL);
    const homePageURL = page.url();
    console.log("Sony 3D Creation Home Page URL::= " + homePageURL);
    expect(homePageURL).toBe(sony3DHomePageURL);
    await expect(page).toHaveTitle('XYZ Capture');

    // Click on Login Button to Navigate to Login page
    const loginButton = page.getByRole('button', { name: 'Login' });
    await expect(loginButton).toBeVisible();

    //Click on Login Button
    await loginButton.click();
    const expectedLoginURL = sonyLoginPageURL;
    const currentLoginURL = page.url();
    console.log("Sony 3D Login URL::= ", currentLoginURL);
    expect(currentLoginURL).toBe(expectedLoginURL);

    const welcomeMessage = await (page.getByText('Welcome'));
    expect(welcomeMessage).toBeVisible();

    // verify sign in with Google Button.
    const googleSignInButton = page.getByRole('button', { name: 'Sign in with Google' });
    await googleSignInButton.waitFor({ state: 'visible' });
    expect(googleSignInButton).toBeVisible();
    await googleSignInButton.click();
    if (googleSignInButton) {
        console.log("Login Button is clicked successfully.")
    } else {
        console.error("Login Button is not clicked successfully.")
    }

    const scrollY = await page.evaluate(() => document.body.scrollHeight); // get the page height
    await page.mouse.wheel(0, scrollY); // scroll to the bottom


    await page.setExtraHTTPHeaders({
        'accept-language': 'en-US,en;q=0.9,hy=0.8'

    });

    await page.evaluate(() => {
        localStorage.setItem('authToken', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ')
        localStorage.setItem("loggedIn", true);
        localStorage.setItem('tokenExpiration', '1733415502652');
        localStorage.setItem('refreshToken', '1//0eJH0C9YQixpICgYIARAAGA4SNwF-L9IrNgiFdIjTkUvi_c0d2bM7SLhir1kkt7gbKLsL5G8sjVGW1kgNPopagegqmB99tjKoyeU');
    });


    let bearerToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ'

    page.on('route', (route, request) => {
        const modifieldHeaders = {
            ...request.headers(),
            'Authorization': `Bearer ${bearerToken}`
        }
        route.continue({ headers: modifieldHeaders })
    });

    await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/3d-creation");
    const creation3DPageURL = page.url();
    console.log("Sony 3D Creation Web Page URL::= " + creation3DPageURL);
    //expect(creation3DPageURL).toBe(expectedCreation3DPage);
    await expect(page).toHaveTitle('XYZ Capture');

    //Verify Sony Logo
    const imageSelector = '#root > div > header > img';
    await page.waitForSelector(imageSelector, { state: 'visible' });
    console.log("Sony Image LOGO Present in the page");
    const imgSrc = await page.getAttribute(imageSelector, 'src');
    console.log(imgSrc);
    if (imgSrc == '/static/media/sony-logo.793747a6e91237b8077ec0576d61e364.svg') {
        console.log("Sony Logo is Showing");
    } else {
        console.log("Sony Logo is Not Showing");
    }

    const creationTextExists = page.locator('//div[@class="appStorePortalHeader" and text()= "3D Capture Creation"]');
    const creationSuiteTextBoundingBox = await creationTextExists.boundingBox();
    console.log("Sony XYZ Creation Suite Bounding Box Dimentions::=", creationSuiteTextBoundingBox);

    await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/main/cdd935fc-20f4-42f8-8f4e-d550a4519413/2d");
    const creation3DMainPageURL = page.url();
    console.log("Sony 3D Main Web Page URL::= " + creation3DMainPageURL);


    await page.reload();

    // Create A New Project

    const createNewProject = page.getByRole('button', { name: 'Create New' });
    await createNewProject.waitFor({ state: 'visible' });
    expect(createNewProject).toBeVisible();
    createNewProject.click();


    const uploadSelectImages = page.locator('//input[@id="fileElem"]');
    //uploadSelectImages.click();

    // upload multiple Images
    const multipleImagesPaths = [
        './tests/ImagesToUpload/000001.png',
        './tests/ImagesToUpload/000002.png',
        './tests/ImagesToUpload/000003.png',
        './tests/ImagesToUpload/000004.png',
        './tests/ImagesToUpload/000005.png',
        './tests/ImagesToUpload/000006.png',
        './tests/ImagesToUpload/000007.png',
        './tests/ImagesToUpload/000008.png',
        './tests/ImagesToUpload/000009.png',
        './tests/ImagesToUpload/000010.png',
    ]
    await uploadSelectImages.setInputFiles(multipleImagesPaths);

    const uploadButton = page.locator('//button[@class="primary"]');
    await uploadButton.waitFor({ state: 'visible' });
    expect(uploadButton).toBeVisible();
    await uploadButton.click();
    if (uploadButton) {
        console.log("upload Button is clicked successfully.")
    } else {
        console.error("upload Button is not clicked successfully.")
    }

    // Click 3D Model Button
    const button3dModelGeneration = page.locator('//button[@class="outline" and text()="3D Model Generation"]');
    await button3dModelGeneration.waitFor({ state: 'visible' });
    expect(button3dModelGeneration).toBeVisible();
    await button3dModelGeneration.click();
    if (button3dModelGeneration) {
        console.log("3dModel Generation Button is clicked successfully.")
    } else {
        console.error("3dModel Generation Button is not clicked successfully.")
    }

    // Select Sony NERF Algorithm
    //selectNERFAlgo
    const selectNERFAlgo = page.locator('//div[@class="profile-selection-footer" and text()="Sony NeRF"]');
    await selectNERFAlgo.waitFor({ state: 'visible' });
    expect(selectNERFAlgo).toBeVisible();
    await selectNERFAlgo.click();
    if (selectNERFAlgo) {
        console.log("Sony NeRF Algorithm Image is clicked successfully.")
    } else {
        console.error("Sony NeRF Algorithm Image is not clicked successfully.")
    }

    // Click on Next Button
    const nextButtonClick = page.locator('//button[@class="primary" and text()="Next"]');
    await nextButtonClick.waitFor({ state: 'visible' });
    expect(nextButtonClick).toBeVisible();
    await nextButtonClick.click();
    if (nextButtonClick) {
        console.log("Next Button is clicked successfully.")
    } else {
        console.error("Next Button is not clicked successfully.")
    }


   // Select All Check Boxes
   const meshCheckBox = await page.locator('//label[@class="global-checkbox-label" and @for="3"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="1"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="2"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="3"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="4"]');
   await meshCheckBox.click();
   if(meshCheckBox) {
       console.log("mesh Check Box is clicked successfully.")
   }
   else {
       console.error("mesh Check Box is not clicked successfully.")
   }

    // Click on Ok Button
    const okButton = page.locator('//button[@class="primary" and text()="Ok"]');
    await okButton.waitFor({ state: 'visible' });
    expect(okButton).toBeVisible();
    await okButton.click();
    if (okButton) {
        console.log("Ok Button is clicked successfully.")
    } else {
        console.error("OK Button is not clicked successfully.")
    }

    // Dismiss Pop up Message
    const dismisspopup = page.locator('//div[@class="text-wrapper" and text()="DISMISS"]');
    await dismisspopup.waitFor({ state: 'visible' });
    expect(dismisspopup).toBeVisible();
    await dismisspopup.click();
    if (dismisspopup) {
        console.log("Dismiss popup is clicked successfully.")
    } else {
        console.error("Dismiss popup is not clicked successfully.")
    }



});



test('Verify Generation of 3D Model Using First Sony Algorithm Sony NERF Include Texture', async ({ page }) => {
    await page.goto(sony3DHomePageURL);
    await page.waitForURL(sony3DHomePageURL);
    const homePageURL = page.url();
    console.log("Sony 3D Creation Home Page URL::= " + homePageURL);
    expect(homePageURL).toBe(sony3DHomePageURL);
    await expect(page).toHaveTitle('XYZ Capture');

    // Click on Login Button to Navigate to Login page
    const loginButton = page.getByRole('button', { name: 'Login' });
    await expect(loginButton).toBeVisible();

    //Click on Login Button
    await loginButton.click();
    const expectedLoginURL = sonyLoginPageURL;
    const currentLoginURL = page.url();
    console.log("Sony 3D Login URL::= ", currentLoginURL);
    expect(currentLoginURL).toBe(expectedLoginURL);

    const welcomeMessage = await (page.getByText('Welcome'));
    expect(welcomeMessage).toBeVisible();

    // verify sign in with Google Button.
    const googleSignInButton = page.getByRole('button', { name: 'Sign in with Google' });
    await googleSignInButton.waitFor({ state: 'visible' });
    expect(googleSignInButton).toBeVisible();
    await googleSignInButton.click();
    if (googleSignInButton) {
        console.log("Login Button is clicked successfully.")
    } else {
        console.error("Login Button is not clicked successfully.")
    }

    const scrollY = await page.evaluate(() => document.body.scrollHeight); // get the page height
    await page.mouse.wheel(0, scrollY); // scroll to the bottom


    await page.setExtraHTTPHeaders({
        'accept-language': 'en-US,en;q=0.9,hy=0.8'

    });

    await page.evaluate(() => {
        localStorage.setItem('authToken', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ')
        localStorage.setItem("loggedIn", true);
        localStorage.setItem('tokenExpiration', '1733415502652');
        localStorage.setItem('refreshToken', '1//0eJH0C9YQixpICgYIARAAGA4SNwF-L9IrNgiFdIjTkUvi_c0d2bM7SLhir1kkt7gbKLsL5G8sjVGW1kgNPopagegqmB99tjKoyeU');
    });


    let bearerToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ'

    page.on('route', (route, request) => {
        const modifieldHeaders = {
            ...request.headers(),
            'Authorization': `Bearer ${bearerToken}`
        }
        route.continue({ headers: modifieldHeaders })
    });

    await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/3d-creation");
    const creation3DPageURL = page.url();
    console.log("Sony 3D Creation Web Page URL::= " + creation3DPageURL);
    //expect(creation3DPageURL).toBe(expectedCreation3DPage);
    await expect(page).toHaveTitle('XYZ Capture');

    //Verify Sony Logo
    const imageSelector = '#root > div > header > img';
    await page.waitForSelector(imageSelector, { state: 'visible' });
    console.log("Sony Image LOGO Present in the page");
    const imgSrc = await page.getAttribute(imageSelector, 'src');
    console.log(imgSrc);
    if (imgSrc == '/static/media/sony-logo.793747a6e91237b8077ec0576d61e364.svg') {
        console.log("Sony Logo is Showing");
    } else {
        console.log("Sony Logo is Not Showing");
    }

    const creationTextExists = page.locator('//div[@class="appStorePortalHeader" and text()= "3D Capture Creation"]');
    const creationSuiteTextBoundingBox = await creationTextExists.boundingBox();
    console.log("Sony XYZ Creation Suite Bounding Box Dimentions::=", creationSuiteTextBoundingBox);

    await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/main/cdd935fc-20f4-42f8-8f4e-d550a4519413/2d");
    const creation3DMainPageURL = page.url();
    console.log("Sony 3D Main Web Page URL::= " + creation3DMainPageURL);


    await page.reload();

    // Create A New Project

    const createNewProject = page.getByRole('button', { name: 'Create New' });
    await createNewProject.waitFor({ state: 'visible' });
    expect(createNewProject).toBeVisible();
    createNewProject.click();


    const uploadSelectImages = page.locator('//input[@id="fileElem"]');
    //uploadSelectImages.click();

    // upload multiple Images
    const multipleImagesPaths = [
        './tests/ImagesToUpload/000001.png',
        './tests/ImagesToUpload/000002.png',
        './tests/ImagesToUpload/000003.png',
        './tests/ImagesToUpload/000004.png',
        './tests/ImagesToUpload/000005.png',
        './tests/ImagesToUpload/000006.png',
        './tests/ImagesToUpload/000007.png',
        './tests/ImagesToUpload/000008.png',
        './tests/ImagesToUpload/000009.png',
        './tests/ImagesToUpload/000010.png',
    ]
    await uploadSelectImages.setInputFiles(multipleImagesPaths);

    const uploadButton = page.locator('//button[@class="primary"]');
    await uploadButton.waitFor({ state: 'visible' });
    expect(uploadButton).toBeVisible();
    await uploadButton.click();
    if (uploadButton) {
        console.log("upload Button is clicked successfully.")
    } else {
        console.error("upload Button is not clicked successfully.")
    }

    // Click 3D Model Button
    const button3dModelGeneration = page.locator('//button[@class="outline" and text()="3D Model Generation"]');
    await button3dModelGeneration.waitFor({ state: 'visible' });
    expect(button3dModelGeneration).toBeVisible();
    await button3dModelGeneration.click();
    if (button3dModelGeneration) {
        console.log("3dModel Generation Button is clicked successfully.")
    } else {
        console.error("3dModel Generation Button is not clicked successfully.")
    }

    // Select Sony NERF Algorithm
    //selectNERFAlgo
    const selectNERFAlgo = page.locator('//div[@class="profile-selection-footer" and text()="Sony NeRF"]');
    await selectNERFAlgo.waitFor({ state: 'visible' });
    expect(selectNERFAlgo).toBeVisible();
    await selectNERFAlgo.click();
    if (selectNERFAlgo) {
        console.log("Sony NeRF Algorithm Image is clicked successfully.")
    } else {
        console.error("Sony NeRF Algorithm Image is not clicked successfully.")
    }

    // Click on Next Button
    const nextButtonClick = page.locator('//button[@class="primary" and text()="Next"]');
    await nextButtonClick.waitFor({ state: 'visible' });
    expect(nextButtonClick).toBeVisible();
    await nextButtonClick.click();
    if (nextButtonClick) {
        console.log("Next Button is clicked successfully.")
    } else {
        console.error("Next Button is not clicked successfully.")
    }


   // Select All Check Boxes
   const textureCheckBox = await page.locator('//label[@class="global-checkbox-label" and @for="4"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="1"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="2"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="3"]');
   await page.uncheck('//label[@class="global-checkbox-label" and @for="4"]');
   await textureCheckBox.click();
   if(textureCheckBox) {
       console.log("Texture Check Box is clicked successfully.")
   }
   else {
       console.error("Texture Check Box is not clicked successfully.")
   }

    // Click on Ok Button
    const okButton = page.locator('//button[@class="primary" and text()="Ok"]');
    await okButton.waitFor({ state: 'visible' });
    expect(okButton).toBeVisible();
    await okButton.click();
    if (okButton) {
        console.log("Ok Button is clicked successfully.")
    } else {
        console.error("OK Button is not clicked successfully.")
    }

    // Dismiss Pop up Message
    const dismisspopup = page.locator('//div[@class="text-wrapper" and text()="DISMISS"]');
    await dismisspopup.waitFor({ state: 'visible' });
    expect(dismisspopup).toBeVisible();
    await dismisspopup.click();
    if (dismisspopup) {
        console.log("Dismiss popup is clicked successfully.")
    } else {
        console.error("Dismiss popup is not clicked successfully.")
    }



});



test('Verify Generation of 3D Model Using First Sony Algorithm Sony NERF Select ALL', async ({ page }) => {
    await page.goto(sony3DHomePageURL);
    await page.waitForURL(sony3DHomePageURL);
    const homePageURL = page.url();
    console.log("Sony 3D Creation Home Page URL::= " + homePageURL);
    expect(homePageURL).toBe(sony3DHomePageURL);
    await expect(page).toHaveTitle('XYZ Capture');

    // Click on Login Button to Navigate to Login page
    const loginButton = page.getByRole('button', { name: 'Login' });
    await expect(loginButton).toBeVisible();
    //Click on Login Button
    await loginButton.click();
    const expectedLoginURL = sonyLoginPageURL;
    const currentLoginURL = page.url();
    console.log("Sony 3D Login URL::= ", currentLoginURL);
    expect(currentLoginURL).toBe(expectedLoginURL);

    const welcomeMessage = await (page.getByText('Welcome'));
    expect(welcomeMessage).toBeVisible();

    // verify sign in with Google Button.
    const googleSignInButton = page.getByRole('button', { name: 'Sign in with Google' });
    await googleSignInButton.waitFor({ state: 'visible' });
    expect(googleSignInButton).toBeVisible();
    await googleSignInButton.click();
    if (googleSignInButton) {
        console.log("Login Button is clicked successfully.")
    } else {
        console.error("Login Button is not clicked successfully.")
    }

    const scrollY = await page.evaluate(() => document.body.scrollHeight); // get the page height
    await page.mouse.wheel(0, scrollY); // scroll to the bottom



    await page.setExtraHTTPHeaders({
        'accept-language': 'en-US,en;q=0.9,hy=0.8'

    });

    await page.evaluate(() => {
        localStorage.setItem('authToken', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ')
        localStorage.setItem("loggedIn", true);
        localStorage.setItem('tokenExpiration', '1733415502652');
        localStorage.setItem('refreshToken', '1//0eJH0C9YQixpICgYIARAAGA4SNwF-L9IrNgiFdIjTkUvi_c0d2bM7SLhir1kkt7gbKLsL5G8sjVGW1kgNPopagegqmB99tjKoyeU');
    });


    let bearerToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ'

    page.on('route', (route, request) => {
        const modifieldHeaders = {
            ...request.headers(),
            'Authorization': `Bearer ${bearerToken}`
        }
        route.continue({ headers: modifieldHeaders })
    });

    await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/3d-creation");
    const creation3DPageURL = page.url();
    console.log("Sony 3D Creation Web Page URL::= " + creation3DPageURL);
    //expect(creation3DPageURL).toBe(expectedCreation3DPage);
    await expect(page).toHaveTitle('XYZ Capture');




    //Verify Sony Logo
    const imageSelector = '#root > div > header > img';
    await page.waitForSelector(imageSelector, { state: 'visible' });
    console.log("Sony Image LOGO Present in the page");
    const imgSrc = await page.getAttribute(imageSelector, 'src');
    console.log(imgSrc);
    if (imgSrc == '/static/media/sony-logo.793747a6e91237b8077ec0576d61e364.svg') {
        console.log("Sony Logo is Showing");
    } else {
        console.log("Sony Logo is Not Showing");
    }

    const creationTextExists = page.locator('//div[@class="appStorePortalHeader" and text()= "3D Capture Creation"]');
    const creationSuiteTextBoundingBox = await creationTextExists.boundingBox();
    console.log("Sony XYZ Creation Suite Bounding Box Dimentions::=", creationSuiteTextBoundingBox);

    await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/main/cdd935fc-20f4-42f8-8f4e-d550a4519413/2d");
    const creation3DMainPageURL = page.url();
    console.log("Sony 3D Main Web Page URL::= " + creation3DMainPageURL);


    await page.reload();

    // Create A New Project

    const createNewProject = page.getByRole('button', { name: 'Create New' });
    await createNewProject.waitFor({ state: 'visible' });
    expect(createNewProject).toBeVisible();
    createNewProject.click();


    const uploadSelectImages = page.locator('//input[@id="fileElem"]');
    //uploadSelectImages.click();

    // upload multiple Images
    const multipleImagesPaths = [
        './tests/ImagesToUpload/000001.png',
        './tests/ImagesToUpload/000002.png',
        './tests/ImagesToUpload/000003.png',
        './tests/ImagesToUpload/000004.png',
        './tests/ImagesToUpload/000005.png',
        './tests/ImagesToUpload/000006.png',
        './tests/ImagesToUpload/000007.png',
        './tests/ImagesToUpload/000008.png',
        './tests/ImagesToUpload/000009.png',
        './tests/ImagesToUpload/000010.png',
    ]
    await uploadSelectImages.setInputFiles(multipleImagesPaths);

    const uploadButton = page.locator('//button[@class="primary"]');
    await uploadButton.waitFor({ state: 'visible' });
    expect(uploadButton).toBeVisible();
    await uploadButton.click();
    if (uploadButton) {
        console.log("upload Button is clicked successfully.")
    } else {
        console.error("upload Button is not clicked successfully.")
    }

    // Click 3D Model Button
    const button3dModelGeneration = page.locator('//button[@class="outline" and text()="3D Model Generation"]');
    await button3dModelGeneration.waitFor({ state: 'visible' });
    expect(button3dModelGeneration).toBeVisible();
    await button3dModelGeneration.click();
    if (button3dModelGeneration) {
        console.log("3dModel Generation Button is clicked successfully.")
    } else {
        console.error("3dModel Generation Button is not clicked successfully.")
    }

    // Select Sony NERF Algorithm
    //selectNERFAlgo
    const selectNERFAlgo = page.locator('//div[@class="profile-selection-footer" and text()="Sony NeRF"]');
    await selectNERFAlgo.waitFor({ state: 'visible' });
    expect(selectNERFAlgo).toBeVisible();
    await selectNERFAlgo.click();
    if (selectNERFAlgo) {
        console.log("Sony PhotoGrammetry Algorithm Image is clicked successfully.")
    } else {
        console.error("Sony PhotoGrammetry Algorithm Image is not clicked successfully.")
    }

    // Click on Next Button
    const nextButtonClick = page.locator('//button[@class="primary" and text()="Next"]');
    await nextButtonClick.waitFor({ state: 'visible' });
    expect(nextButtonClick).toBeVisible();
    await nextButtonClick.click();
    if (nextButtonClick) {
        console.log("Next Button is clicked successfully.")
    } else {
        console.error("Next Button is not clicked successfully.")
    }

    // Select All Check Boxes
    const sparseCheckBox = await page.locator('//label[@class="global-checkbox-label" and @for="1"]');
    const denseCheckBox = await page.locator('//label[@class="global-checkbox-label" and @for="2"]');
    const meshCheckBox = await page.locator('//label[@class="global-checkbox-label" and @for="3"]');
    const textureCheckBox = await page.locator('//label[@class="global-checkbox-label" and @for="4"]');

    await page.uncheck('//label[@class="global-checkbox-label" and @for="1"]');
    await page.uncheck('//label[@class="global-checkbox-label" and @for="2"]');
    await page.uncheck('//label[@class="global-checkbox-label" and @for="3"]');
    await page.uncheck('//label[@class="global-checkbox-label" and @for="4"]');
    await sparseCheckBox.click();
    if(sparseCheckBox) {
        console.log("Sparse Check Box is clicked successfully.")
    }
    else {
        console.error("Sparse Check Box is not clicked successfully.")
    }
    await denseCheckBox.click();
    if(denseCheckBox) {
        console.log("Dense Check Box is clicked successfully.")
    }
    else {
        console.error("Dense Check Box is not clicked successfully.")
    }

    await meshCheckBox.click();
    if(denseCheckBox) {
        console.log("Mesh Check Box is clicked successfully.")
    }
    else {
        console.error("Mesh Check Box is not clicked successfully.")
    }

    await textureCheckBox.click();

    if(textureCheckBox) {
        console.log("Texture Check Box is clicked successfully.")
    }
    else {
        console.error("Texture Check Box is not clicked successfully.")
    }
    // Click on Ok Button
    const okButton = page.locator('//button[@class="primary" and text()="Ok"]');
    await okButton.waitFor({ state: 'visible' });
    expect(okButton).toBeVisible();
    await okButton.click();
    if (okButton) {
        console.log("Ok Button is clicked successfully.")
    } else {
        console.error("OK Button is not clicked successfully.")
    }

    // Dismiss Pop up Message
    const dismisspopup = page.locator('//div[@class="text-wrapper" and text()="DISMISS"]');
    await dismisspopup.waitFor({ state: 'visible' });
    expect(dismisspopup).toBeVisible();
    await dismisspopup.click();
    if (dismisspopup) {
        console.log("Dismiss popup is clicked successfully.")
    } else {
        console.error("Dismiss popup is not clicked successfully.")
    }



});

