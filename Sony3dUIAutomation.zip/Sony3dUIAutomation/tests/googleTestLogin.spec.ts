import { test, expect, chromium, BrowserContext } from '@playwright/test';
//let sony3DHomePageURL = 'https://sonyxyzfrontend-test.azurewebsites.net/?code=4%2F0AeanS0ZRmJmYUKoOGrIMHPctDSX2oreLAqJ0XdAVSTKVm2hLEQqEVbQyYRE9KojjHQXzXQ&scope=profile+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile';
let sonyLoginPageURL = 'https://sonyxyzfrontend-test.azurewebsites.net/#/login';
let sony3DHomePageURL = 'https://sonyxyzfrontend-test.azurewebsites.net'

test('Verify google Login popup', async ({ page }) => {

    await page.goto(sonyLoginPageURL);
    await page.waitForURL(sonyLoginPageURL);
    await page.evaluate(()=>{
        localStorage.setItem('authToken','eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ')
        localStorage.setItem("loggedIn",true);
        localStorage.setItem('tokenExpiration', '1733415502652');
        localStorage.setItem('refreshToken', '1//0eJH0C9YQixpICgYIARAAGA4SNwF-L9IrNgiFdIjTkUvi_c0d2bM7SLhir1kkt7gbKLsL5G8sjVGW1kgNPopagegqmB99tjKoyeU');
    })
   // await page.goto('https://accounts.google.com/o/oauth2/v2/auth?client_id=902583710007-rvq19cgp690o9a4pjlf8krpj20abpeai.apps.googleusercontent.com&redirect_uri=https://sonyxyzfrontend-test.azurewebsites.net&response_type=code&scope=https://www.googleapis.com/auth/userinfo.profile&access_type=offline')
    await page.goto(sony3DHomePageURL);

    await page.waitForURL(sony3DHomePageURL);
    const homePageURL = page.url();
    console.log("Sony 3D Creation Home Page URL::= " + homePageURL);
   // expect(homePageURL).toBe(sony3DHomePageURL);

    const imageSelector = '#root > div > header > img';
    await page.waitForSelector(imageSelector, { state: 'visible' });
    await expect(page).toHaveTitle('XYZ Capture');
    // let bearerToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDYyODkxNDUyNzM1MzQ2Nzg1NzAiLCJlbWFpbCI6ImFuanV0ZXN0d29ya0BnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXRfaGFzaCI6IlpqUnNjQ3A5TmJNTDFOSHpXRmtsWEEiLCJuYW1lIjoiYW5qdSB0ZXN0IiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0wzbTB0VW5weEJHRTR2QTg2MzJCN2RfeWs4MGJ4UWxRUEFJTFU4QnFxVjZUeXpxdz1zOTYtYyIsImdpdmVuX25hbWUiOiJhbmp1IiwiZmFtaWx5X25hbWUiOiJ0ZXN0IiwiaWF0IjoxNzMzNDExOTAzLCJleHAiOjE3MzM0MTU1MDN9.oOHUTS3OUKIydq3fILr00mmrtclgn6Hm2Qetz4ntGmu9mrXKrP-NiA1-csxntPM4CT06ERbg-vpKnLOsvPF-N5dUccJdNEf2nE9W2-L_rGo1-kTaWIwU9-Kyd-fMTQIM9tpkyTpSytoqLwomtLyy486VKdQd0EKWTXibu9HgRY9rOafykUlztBvEf5m4wq9gVbDCd388_8w8zhkZKfeemC49oyHrjc5WkChMYxPXPfi58imO80IaTLqUfL4wzJ5vN_0KOo2SNb70ShspymSn2mO_Bf2arCJYbb02lsPYVicNyCYAcsMVudsX6oiLBq6lEQJ3ZzO8QO_lnskJwfO3tg'

    // page.on('route' , (route,request)=>{
    //     const modifieldHeaders = {
    //         ...request.headers(),
    //         'Authorization':`Bearer ${bearerToken}`
    //     }
    //     route.continue({headers:modifieldHeaders})
    // })
    // await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/3d-creation");
    const portalClick = page.locator('.main-portal').first();
    // Click on Login Button to Navigate to Login page
   // const loginButton = page.getByRole('button', { name: 'Login' });
    //await expect(loginButton).toBeVisible();

    //Click on Login Button
    //const firstClassElem = page.locator(`.${firstClass}`);
    await page.waitForLoadState('load')
     await portalClick?.click();
    

     const creationClick = page.locator('.main').first();

     await creationClick.click();
     await page.waitForLoadState('load')



});