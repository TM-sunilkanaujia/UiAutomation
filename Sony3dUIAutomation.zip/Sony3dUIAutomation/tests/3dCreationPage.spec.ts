import { test, expect, chromium, BrowserContext } from '@playwright/test';
let sony3DHomePageURL = 'https://sonyxyzfrontend-test.azurewebsites.net/';
let sonyLoginPageURL = 'https://sonyxyzfrontend-test.azurewebsites.net/#/login';


const clientId = '902583710007-rvq19cgp690o9a4pjlf8krpj20abpeai.apps.googleusercontent.com';
const clientSecret = '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';
const redirectUri = 'https://sonyxyzfrontend-test.azurewebsites.net';
const authorizationEndpoint = 'https://accounts.google.com/o/oauth2/v2/auth';
const tokenEndPoint = 'https://oauth2.googleapis.com/token';

test('Verify 3d Creation Web Page All Components', async ({ page }) => {
    await page.goto(sony3DHomePageURL);
    await page.waitForURL(sony3DHomePageURL);
    const homePageURL = page.url();
    console.log("Sony 3D Creation Home Page URL::= " + homePageURL);
    expect(homePageURL).toBe(sony3DHomePageURL);
    await expect(page).toHaveTitle('XYZ Capture');

    // Click on Login Button to Navigate to Login page
    const loginButton = page.getByRole('button', { name: 'Login' });
    await expect(loginButton).toBeVisible();
    //Click on Login Button
    await loginButton.click();
    const expectedLoginURL = sonyLoginPageURL;
    const currentLoginURL = page.url();
    console.log("Sony 3D Login URL::= ", currentLoginURL);
    expect(currentLoginURL).toBe(expectedLoginURL);

    const welcomeMessage = await (page.getByText('Welcome'));
    expect(welcomeMessage).toBeVisible();

    // verify sign in with Google Button.
    const googleSignInButton = page.getByRole('button', { name: 'Sign in with Google' });
    await googleSignInButton.waitFor({ state: 'visible' });
    expect(googleSignInButton).toBeVisible();
    await googleSignInButton.click();
    if (googleSignInButton) {
        console.log("Login Button is clicked successfully.")
    } else {
        console.error("Login Button is not clicked successfully.")
    }

    const scrollY = await page.evaluate(() => document.body.scrollHeight); // get the page height
    await page.mouse.wheel(0, scrollY); // scroll to the bottom



    await page.setExtraHTTPHeaders({
        'accept-language': 'en-US,en;q=0.9,hy=0.8'

    });

    await page.evaluate(() => {
        localStorage.setItem('authToken', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ')
        localStorage.setItem("loggedIn", true);
        localStorage.setItem('tokenExpiration', '1733415502652');
        localStorage.setItem('refreshToken', '1//0eJH0C9YQixpICgYIARAAGA4SNwF-L9IrNgiFdIjTkUvi_c0d2bM7SLhir1kkt7gbKLsL5G8sjVGW1kgNPopagegqmB99tjKoyeU');
    });


    let bearerToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ'

    page.on('route', (route, request) => {
        const modifieldHeaders = {
            ...request.headers(),
            'Authorization': `Bearer ${bearerToken}`
        }
        route.continue({ headers: modifieldHeaders })
    });
    
    await page.goto("https://sonyxyzfrontend-test.azurewebsites.net/#/3d-creation");
    const creation3DPageURL = page.url();
    console.log("Sony 3D Creation Web Page URL::= " + creation3DPageURL);
    //expect(creation3DPageURL).toBe(expectedCreation3DPage);
    await expect(page).toHaveTitle('XYZ Capture');


    // Verify XYZ All Tabs [Top, Product,App & Service,SDK,Whats New
    await expect(page.getByText('Top')).toBeVisible();
    await expect(page.getByRole('list')).toContainText('Top');

    await expect(page.getByText('Product')).toBeVisible();
    await expect(page.getByRole('list')).toContainText('Product');

    await expect(page.locator('#selected')).toContainText('App & Service');

    await expect(page.getByText('SDK')).toBeVisible();
    await expect(page.getByRole('list')).toContainText('SDK');
    const lastTab = "What's New";
    await expect(page.getByText(lastTab)).toBeVisible();
    await expect(page.getByRole('list')).toContainText('What\'s New');

    const homepageTabList = await page.locator('.wrapper > ul');
    const tabs = await homepageTabList.locator('li');
    console.log("Home page Tabs::=", tabs);
    const tabCount = await tabs.count();
    console.log("Home Page Tabs Count ::=", tabCount);
    expect(tabCount).toBe(5);

    const expectedTabs = ['Top', 'Product', 'App & Service', 'SDK', 'What\'s New'];
    for (let i = 0; i < tabCount; i++) {
        const tabText = await tabs.nth(i).textContent();
        expect(tabText?.trim()).toBe(expectedTabs[i]);

    }

//Verify Sony Logo
const imageSelector = '#root > div > header > img';
await page.waitForSelector(imageSelector, { state: 'visible' });
console.log("Sony Image LOGO Present in the page");
const imgSrc = await page.getAttribute(imageSelector, 'src');
console.log(imgSrc);
if (imgSrc == '/static/media/sony-logo.793747a6e91237b8077ec0576d61e364.svg') {
  console.log("Sony Logo is Showing");
} else {
  console.log("Sony Logo is Not Showing");
}

const creationTextExists = page.locator('//div[@class="appStorePortalHeader" and text()= "3D Capture Creation"]');
  const creationSuiteTextBoundingBox = await creationTextExists.boundingBox();
  console.log("Sony XYZ Creation Suite Bounding Box Dimentions::=", creationSuiteTextBoundingBox);

    /*
    
    //https://accounts.google.com/o/oauth2/v2/auth/oauthchooseaccount?client_id=902583710007-rvq19cgp690o9a4pjlf8krpj20abpeai.apps.googleusercontent.com&redirect_uri=https%3A%2F%2Fsonyxyzfrontend-test.azurewebsites.net&response_type=code&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile&access_type=offline&service=lso&o2v=2&ddm=1&flowName=GeneralOAuthFlow
    
        //const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth/oauthchooseaccount?client_id=902583710007-rvq19cgp690o9a4pjlf8krpj20abpeai.apps.googleusercontent.com&redirect_uri=https%3A%2F%2Fsonyxyzfrontend-test.azurewebsites.net&response_type=code&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile&access_type=offline&service=lso&o2v=2&ddm=1&flowName=GeneralOAuthFlow');
    
        //console.log("Google Auth Login URL::= ", authUrl);
        //authUrl.searchParams.append('response_type', 'code');
        //authUrl.searchParams.append('client_id', clientId);
        //authUrl.searchParams.append('redirect_uri', redirectUri);
        //authUrl.searchParams.append('scope', 'https://www.googleapis.com/auth/userinfo.email'); // Example scope
        //authUrl.searchParams.append('access_type', 'offline');  // Optional, if you need refresh tokens
    
       
        //await page.goto(authUrl.toString());
        //await page.waitForSelector('input[type="email"]');
        //const googleUserName = await page.getByLabel('Email or phone').fill('neeraj.upadhayay@sony.com');
        //await page.waitForTimeout(2000);
    
        //const nextButton1 = await page.getByRole('button', { name: 'Next' }).click();
        //expect(nextButton1).toBeVisible();
       // await Promise.all([
         //   page.waitForLoadState(),
         //   await page.keyboard.press('Enter')
    
       ]);
    
        //await page.waitForTimeout(3000);
        //const googlePassword = await page.getByLabel('Enter your password').fill('Sony@123');
       // await Promise.all([
        //    page.waitForLoadState(),
         //   await page.keyboard.press('Enter')
    
       // ]);
       */



});